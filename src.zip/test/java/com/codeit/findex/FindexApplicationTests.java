package com.codeit.findex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FindexApplicationTests {

  @Test
  void contextLoads() {}
}
