package com.codeit.findex.dto.indexData.request;

import java.util.UUID;

public record IndexDataSearchRequest(
        long id
) {
}
