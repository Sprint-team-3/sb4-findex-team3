package com.codeit.findex.dto.dashboard;

public enum ChartPeriodType {
  MONTHLY,
  QUARTERLY,
  YEARLY
}
