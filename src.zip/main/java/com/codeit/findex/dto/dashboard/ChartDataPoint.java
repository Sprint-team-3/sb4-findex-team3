package com.codeit.findex.dto.dashboard;

import java.time.LocalDate;

public record ChartDataPoint(LocalDate date, double value) {}
