package com.codeit.findex.dto.dashboard;

public enum PeriodType {
  DAILY,
  WEEKLY,
  MONTHLY
}
