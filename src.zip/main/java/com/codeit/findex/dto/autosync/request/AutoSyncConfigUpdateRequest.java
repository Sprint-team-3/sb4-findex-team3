package com.codeit.findex.dto.autosync.request;

public record AutoSyncConfigUpdateRequest(boolean enabled) {}
