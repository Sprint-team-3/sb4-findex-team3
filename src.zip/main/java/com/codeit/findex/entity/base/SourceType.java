package com.codeit.findex.entity.base;

public enum SourceType {
    USER,
    OPEN_API,
}
