package com.codeit.findex.entityEnum;

public enum Result {
  SUCCESS,
  FAILED
}
