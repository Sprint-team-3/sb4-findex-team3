package com.codeit.findex.entityEnum;

public enum JobType {
  INDEX_INFO,
  INDEX_DATA
}
