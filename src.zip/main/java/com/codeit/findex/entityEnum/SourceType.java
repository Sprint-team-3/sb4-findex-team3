package com.codeit.findex.entityEnum;

public enum SourceType {
  USER,
  OPEN_API
}
