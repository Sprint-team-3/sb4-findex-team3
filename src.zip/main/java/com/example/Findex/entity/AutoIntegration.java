package com.example.Findex.entity;

public class AutoIntegration {}
